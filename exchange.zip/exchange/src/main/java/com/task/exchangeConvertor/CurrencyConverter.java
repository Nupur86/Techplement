package com.task.exchangeConvertor;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Scanner;


public class CurrencyConverter {
	 public static void main(String[] args) throws IOException {

	        Scanner scanner = new Scanner(System.in);
	        System.out.println("Type currency to convert from");
	        String convertFrom = scanner.nextLine();
	        System.out.println("Type currency to convert to");
	        String convertTo = scanner.nextLine();
	        System.out.println("Type quantity to convert");
	        BigDecimal quantity = scanner.nextBigDecimal();
	        String urlString = "https://v6.exchangerate-api.com/v6/6e1ad09e1b027855aeabb9fb/latest/USD";

//	        String urlString = "https://v6.exchangerate-api.com/v6/6e1ad09e1b027855aeabb9fb/latest?base=" + convertFrom.toUpperCase();

//	        OkHttpClient client = new OkHttpClient();
//	        Request request = new Request.Builder()
//	                .url(urlString)
//	                .get()
//	                .build();
//
//	        Response response = client.newCall(request).execute();
//	        String stringResponse = response.body().string();
//	        JSONObject jsonObject = new JSONObject(stringResponse);
//	        JSONObject ratesObject = jsonObject.getJSONObject("rates");
//	        BigDecimal rate = ratesObject.getBigDecimal(convertTo.toUpperCase());
//
//	        BigDecimal result = rate.multiply(quantity);
//	        System.out.println(result);
	        
	        
	        OkHttpClient client = new OkHttpClient();
	        Request request = new Request.Builder().url(urlString).get().build();

	     // Add these lines to check the response code and content type
	     Response response = client.newCall(request).execute();
	     if (!response.isSuccessful()) {
	         throw new RuntimeException("API request failed with status code: " + response.code());
	     }
	     String contentType = response.body().contentType().toString();
	     if (!contentType.startsWith("application/json")) {
	         throw new RuntimeException("Unexpected content type: " + contentType);
	     }

	     // Original code with checks
	     String stringResponse = response.body().string();
	     try {
	    	 
	         JSONObject jsonObject = new JSONObject(stringResponse);
	         JSONObject ratesObject = jsonObject.getJSONObject("conversion_rates");
	         BigDecimal rate = ratesObject.getBigDecimal(convertTo.toUpperCase());

	         BigDecimal result = rate.multiply(quantity);
	         System.out.println(result);
	     } catch (JSONException e) {
	         // Handle specific JSON parsing errors
	         System.err.println("Error parsing JSON response: " + e.getMessage());
	     } catch (Exception e) {
	         // Handle other potential errors
	         System.err.println("An error occurred: " + e.getMessage());
	     }


	    }

}
